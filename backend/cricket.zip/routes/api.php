<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::get('teams', function() {
    // If the Content-Type and Accept headers are set to 'application/json', 
    // this will return a JSON structure. This will be cleaned up later.
    return teams::all();
});
 
Route::get('teams/{id}', function($id) {
    return teams::find($id);
});

Route::get('players/{team_id}', function($id) {
    return players::find($team_id);
});

Route::get('player-history/{id}', function($id) {
    return players::find($id);
});

Route::get('match-details', function($id) {
    return match-details::find($id);
});

Route::get('teams', 'TeamsController@index');
Route::get('teams/{id}', 'TeamsController@show');
Route::get('players/{team_id}', 'PlayersController@index');
Route::get('player-history/{id}', 'PlayersController@playerHistory');
Route::get('match-details', 'MatchDetailsController@index');
