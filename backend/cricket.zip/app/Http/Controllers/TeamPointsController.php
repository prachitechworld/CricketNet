<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Team_points;

class TeamPointsController extends Controller
{
    public function index()
    {
        return Team_points::all();
    }
}
