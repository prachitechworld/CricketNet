<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Player;
use App\Player_history;

class PlayersController extends Controller
{
    public function index($team_id)
    {
        return Player::where(['team_id'=>$team_id])->get();
    }

    public function playerHistory($id)
    {
        return Player_history::where(['player_id'=>$id])->get();
    }
 
 
    
}
