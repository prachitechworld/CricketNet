<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class team_points extends Model
{
    //
}
